#ifndef ___product_generated_h___
#define ___product_generated_h___

#define VBOX_VENDOR "Oracle and/or its affiliates"
#define VBOX_VENDOR_SHORT "Oracle"
#define VBOX_PRODUCT "Oracle VM VirtualBox"
#define VBOX_BUILD_PUBLISHER ""
#define VBOX_C_YEAR "2024"

#endif
