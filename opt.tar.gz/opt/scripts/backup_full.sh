#!/bin/bash

FECHA=$(date +%Y%m%d)


if [[ "$1" == "-help" || "$1" == "--help" ]]; then
  echo "Uso: $0 ORIGEN DESTINO"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo "Hace un backup del directorio ORIGEN al directorio DESTINO"
  exit 0
fi


if [[ $# -ne 2 ]]; then
  echo "Error: Se requieren 2 argumentos: ORIGEN y DESTINO"
  echo "Use -help para ver el uso"
  exit 1
fi

ORIGEN=$1
DESTINO=$2


if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio de origen '$ORIGEN' no existe"
  exit 2
fi


if [[ ! -d "$DESTINO" ]]; then
  echo "Error: El directorio de destino '$DESTINO' no existe"
  exit 3
fi


NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"


tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN"


if [[ $? -eq 0 ]]; then
  echo "Backup realizado con éxito: ${DESTINO}/${ARCHIVO}"
else
  echo "Error al realizar el backup"
  exit 4
fi

exit 0